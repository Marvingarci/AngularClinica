<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TelefonosEmergencia extends Model
{
    //
}
