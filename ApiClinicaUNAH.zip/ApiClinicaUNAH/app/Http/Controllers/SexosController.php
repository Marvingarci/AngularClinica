<?php

namespace App\Http\Controllers;

use App\sexos;
use Illuminate\Http\Request;

class SexosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\sexos  $sexos
     * @return \Illuminate\Http\Response
     */
    public function show(sexos $sexos)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\sexos  $sexos
     * @return \Illuminate\Http\Response
     */
    public function edit(sexos $sexos)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\sexos  $sexos
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, sexos $sexos)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\sexos  $sexos
     * @return \Illuminate\Http\Response
     */
    public function destroy(sexos $sexos)
    {
        //
    }
}
