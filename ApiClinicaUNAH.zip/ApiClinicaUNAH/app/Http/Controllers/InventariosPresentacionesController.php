<?php

namespace App\Http\Controllers;

use App\inventariosPresentaciones;
use Illuminate\Http\Request;

class InventariosPresentacionesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\inventariosPresentaciones  $inventariosPresentaciones
     * @return \Illuminate\Http\Response
     */
    public function show(inventariosPresentaciones $inventariosPresentaciones)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\inventariosPresentaciones  $inventariosPresentaciones
     * @return \Illuminate\Http\Response
     */
    public function edit(inventariosPresentaciones $inventariosPresentaciones)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\inventariosPresentaciones  $inventariosPresentaciones
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, inventariosPresentaciones $inventariosPresentaciones)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\inventariosPresentaciones  $inventariosPresentaciones
     * @return \Illuminate\Http\Response
     */
    public function destroy(inventariosPresentaciones $inventariosPresentaciones)
    {
        //
    }
}
