<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class citas extends Model
{
    protected $primaryKey = 'id_paciente';
}
