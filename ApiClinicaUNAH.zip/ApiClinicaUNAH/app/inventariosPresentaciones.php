<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class inventariosPresentaciones extends Model
{
    //
}
