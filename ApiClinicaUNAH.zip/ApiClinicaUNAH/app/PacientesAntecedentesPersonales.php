<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PacientesAntecedentesPersonales extends Model
{
    //
}
